
const initialBoard = () => {
  const board = Array(64).fill(null);
  const back = ["R", "N", "B", "Q", "K", "B", "N", "R"];

  for (let i = 0; i < 8; i++) {
    board[i] = { type: back[i], color: "b" };
    board[i + 8] = { type: "P", color: "b" };
    board[i + 48] = { type: "P", color: "w" };
    board[i + 56] = { type: back[i], color: "w" };
  }

  return board;
};

const inside = (r, c) => r >= 0 && r < 8 && c >= 0 && c < 8;

export function createPosition() {
  return {
    board: initialBoard(),
    turn: "w",
    rights: { wK: true, wQ: true, bK: true, bQ: true },
    ep: null,
    captured: null,
    lastMove: null,
    halfmove: 0
  };
}

function findKing(board, color) {
  return board.findIndex(p => p?.type === "K" && p.color === color);
}

export function isAttacked(board, square, color) {
  const r = Math.floor(square / 8);
  const c = square % 8;

  const pd = color === "w" ? 1 : -1;

  for (const dc of [-1, 1]) {
    const nr = r + pd;
    const nc = c + dc;
    if (inside(nr, nc)) {
      const p = board[nr * 8 + nc];
      if (p?.type === "P" && p.color === color) return true;
    }
  }

  const knights = [
    [-2,-1],[-2,1],[-1,-2],[-1,2],
    [1,-2],[1,2],[2,-1],[2,1]
  ];

  for (const [dr, dc] of knights) {
    const nr = r + dr;
    const nc = c + dc;
    if (inside(nr, nc)) {
      const p = board[nr * 8 + nc];
      if (p?.type === "N" && p.color === color) return true;
    }
  }

  const dirs = [
    [-1,0],[1,0],[0,-1],[0,1],
    [-1,-1],[-1,1],[1,-1],[1,1]
  ];

  for (let d = 0; d < 8; d++) {
    const [dr, dc] = dirs[d];
    let nr = r + dr;
    let nc = c + dc;
    let distance = 1;

    while (inside(nr, nc)) {
      const p = board[nr * 8 + nc];

      if (p) {
        if (p.color === color) {
          if (
            (distance === 1 && p.type === "K") ||
            (d < 4 && (p.type === "R" || p.type === "Q")) ||
            (d >= 4 && (p.type === "B" || p.type === "Q"))
          ) return true;
        }
        break;
      }

      nr += dr;
      nc += dc;
      distance++;
    }
  }

  return false;
}

export function inCheck(board, color) {
  const king = findKing(board, color);
  return king === -1 || isAttacked(board, king, color === "w" ? "b" : "w");
}

function makeMove(pos, from, to, promotion) {
  const board = [...pos.board];
  const piece = board[from];
  let captured = board[to];

  if (piece.type === "P" && to === pos.ep && !captured) {
    const capturedSquare = to + (piece.color === "w" ? 8 : -8);
    captured = board[capturedSquare];
    board[capturedSquare] = null;
  }

  board[to] = { ...piece, type: promotion || piece.type };
  board[from] = null;

  if (piece.type === "K" && Math.abs(to - from) === 2) {
    const rookFrom = to > from ? from + 3 : from - 4;
    const rookTo = to > from ? from + 1 : from - 1;
    board[rookTo] = board[rookFrom];
    board[rookFrom] = null;
  }

  const rights = { ...pos.rights };

  if (piece.type === "K") {
    rights[piece.color + "K"] = false;
    rights[piece.color + "Q"] = false;
  }

  const rookSquares = [
    [0, "bQ"], [7, "bK"], [56, "wQ"], [63, "wK"]
  ];

  rookSquares.forEach(([sq, key]) => {
    if (from === sq || to === sq) rights[key] = false;
  });

  return {
    board,
    turn: piece.color === "w" ? "b" : "w",
    rights,
    ep: piece.type === "P" && Math.abs(to - from) === 16
      ? (from + to) / 2 : null,
    captured,
    lastMove: { from, to },
    halfmove: piece.type === "P" || captured ? 0 : pos.halfmove + 1
  };
}

function pseudoMoves(pos, from) {
  const board = pos.board;
  const piece = board[from];
  if (!piece) return [];

  const color = piece.color;
  const r = Math.floor(from / 8);
  const c = from % 8;
  const moves = [];

  const add = (nr, nc) => {
    if (!inside(nr, nc)) return false;
    const to = nr * 8 + nc;
    if (board[to]?.color === color) return false;
    moves.push(to);
    return !board[to];
  };

  if (piece.type === "P") {
    const dir = color === "w" ? -1 : 1;
    const start = color === "w" ? 6 : 1;

    if (inside(r + dir, c) && !board[(r + dir) * 8 + c]) {
      moves.push((r + dir) * 8 + c);

      if (r === start && !board[(r + 2 * dir) * 8 + c]) {
        moves.push((r + 2 * dir) * 8 + c);
      }
    }

    for (const dc of [-1, 1]) {
      const nr = r + dir;
      const nc = c + dc;
      if (!inside(nr, nc)) continue;

      const to = nr * 8 + nc;
      if (board[to]?.color === (color === "w" ? "b" : "w") || to === pos.ep) {
        moves.push(to);
      }
    }
  }

  if (piece.type === "N") {
    [
      [-2,-1],[-2,1],[-1,-2],[-1,2],
      [1,-2],[1,2],[2,-1],[2,1]
    ].forEach(([dr, dc]) => add(r + dr, c + dc));
  }

  if (["B", "R", "Q"].includes(piece.type)) {
    const dirs = [];

    if (piece.type !== "B") dirs.push([-1,0],[1,0],[0,-1],[0,1]);
    if (piece.type !== "R") dirs.push([-1,-1],[-1,1],[1,-1],[1,1]);

    dirs.forEach(([dr, dc]) => {
      let nr = r + dr;
      let nc = c + dc;

      while (add(nr, nc)) {
        nr += dr;
        nc += dc;
      }
    });
  }

  if (piece.type === "K") {
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr || dc) add(r + dr, c + dc);
      }
    }

    const row = color === "w" ? 7 : 0;
    const enemy = color === "w" ? "b" : "w";

    if (r === row && c === 4 && !inCheck(board, color)) {
      if (
        pos.rights[color + "K"] &&
        board[row * 8 + 7]?.type === "R" &&
        board[row * 8 + 7]?.color === color &&
        !board[row * 8 + 5] && !board[row * 8 + 6] &&
        !isAttacked(board, row * 8 + 5, enemy) &&
        !isAttacked(board, row * 8 + 6, enemy)
      ) moves.push(row * 8 + 6);

      if (
        pos.rights[color + "Q"] &&
        board[row * 8]?.type === "R" &&
        board[row * 8]?.color === color &&
        !board[row * 8 + 1] && !board[row * 8 + 2] &&
        !board[row * 8 + 3] &&
        !isAttacked(board, row * 8 + 3, enemy) &&
        !isAttacked(board, row * 8 + 2, enemy)
      ) moves.push(row * 8 + 2);
    }
  }

  return moves;
}

export function legalMoves(pos, from) {
  const piece = pos.board[from];
  if (!piece) return [];

  return pseudoMoves(pos, from).filter(to => {
    const promotion = piece.type === "P" && (to < 8 || to >= 56) ? "Q" : undefined;
    const next = makeMove(pos, from, to, promotion);
    return !inCheck(next.board, piece.color);
  });
}

export function getAllMoves(pos, color) {
  const result = [];

  pos.board.forEach((piece, from) => {
    if (piece?.color === color) {
      legalMoves(pos, from).forEach(to => result.push({ from, to }));
    }
  });

  return result;
}

export function playMove(pos, from, to, promotion = "Q") {
  const piece = pos.board[from];

  if (!piece || piece.color !== pos.turn) return null;
  if (!legalMoves(pos, from).includes(to)) return null;

  if (!(piece.type === "P" && (to < 8 || to >= 56))) {
    promotion = undefined;
  }

  return makeMove(pos, from, to, promotion);
}

export function gameStatus(pos) {
  const checked = inCheck(pos.board, pos.turn);
  const moves = getAllMoves(pos, pos.turn);

  if (checked && moves.length === 0) return "checkmate";
  if (!checked && moves.length === 0) return "stalemate";

  return checked ? "check" : "playing";
}

export function notation(before, from, to, after) {
  const piece = before.board[from];
  const target = before.board[to];
  const capture = target || (piece.type === "P" && before.ep === to);

  let san = "";

  if (piece.type === "K" && Math.abs(to - from) === 2) {
    san = to > from ? "O-O" : "O-O-O";
  } else {
    if (piece.type !== "P") san += piece.type;
    if (capture && piece.type === "P") san += "abcdefgh"[from % 8];
    if (capture) san += "x";

    san += "abcdefgh"[to % 8] + (8 - Math.floor(to / 8));

    if (piece.type === "P" && (to < 8 || to >= 56)) {
      san += "=" + after.board[to].type;
    }
  }

  if (inCheck(after.board, after.turn)) {
    san += getAllMoves(after, after.turn).length === 0 ? "#" : "+";
  }

  return san;
}
