
import { useState, useEffect } from "react";
import "./App.css";
import {
  createPosition,
  legalMoves,
  playMove,
  notation,
  gameStatus,
  getAllMoves
} from "./chess";

const symbols = {
  w: { K: "♔", Q: "♕", R: "♖", B: "♗", N: "♘", P: "♙" },
  b: { K: "♚", Q: "♛", R: "♜", B: "♝", N: "♞", P: "♟" }
};

function App() {
  const [position, setPosition] = useState(createPosition);
  const [selected, setSelected] = useState(null);
  const [possible, setPossible] = useState([]);
  const [history, setHistory] = useState([]);
  const [moves, setMoves] = useState([]);
  const [whiteTime, setWhiteTime] = useState(600);
  const [blackTime, setBlackTime] = useState(600);
  const [running, setRunning] = useState(true);
  const [promotion, setPromotion] = useState(null);

  const status = gameStatus(position);
  const timeout = whiteTime === 0 || blackTime === 0;
  const gameOver = status === "checkmate" || status === "stalemate" || timeout;

  useEffect(() => {
    if (!running || gameOver) return;

    const timer = setInterval(() => {
      if (position.turn === "w") {
        setWhiteTime(t => Math.max(0, t - 1));
      } else {
        setBlackTime(t => Math.max(0, t - 1));
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [position.turn, running, gameOver]);

  function formatTime(seconds) {
    return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  }

  function handleSquare(index) {
    if (!running || gameOver || promotion) return;

    const piece = position.board[index];

    if (selected !== null && possible.includes(index)) {
      const currentPiece = position.board[selected];

      if (currentPiece.type === "P" && (index < 8 || index >= 56)) {
        setPromotion({ from: selected, to: index });
        return;
      }

      makeMove(selected, index, "Q");
      return;
    }

    if (piece && piece.color === position.turn) {
      setSelected(index);
      setPossible(legalMoves(position, index));
    } else {
      setSelected(null);
      setPossible([]);
    }
  }

  function makeMove(from, to, promote) {
    const next = playMove(position, from, to, promote);

    if (!next) return;

    const san = notation(position, from, to, next);

    setHistory(prev => [...prev, {
      position,
      moves,
      whiteTime,
      blackTime
    }]);

    setMoves(prev => [...prev, {
      color: position.turn,
      san
    }]);

    setPosition(next);
    setSelected(null);
    setPossible([]);
    setPromotion(null);
  }

  function undoMove() {
    if (!history.length) return;

    const previous = history[history.length - 1];

    setPosition(previous.position);
    setMoves(previous.moves);
    setWhiteTime(previous.whiteTime);
    setBlackTime(previous.blackTime);
    setHistory(history.slice(0, -1));
    setSelected(null);
    setPossible([]);
    setPromotion(null);
  }

  function restartGame() {
    setPosition(createPosition());
    setSelected(null);
    setPossible([]);
    setHistory([]);
    setMoves([]);
    setWhiteTime(600);
    setBlackTime(600);
    setPromotion(null);
    setRunning(true);
  }

  const captured = history.map(h => h.position.captured).filter(Boolean);

  const capturedByWhite = captured.filter(p => p.color === "b");
  const capturedByBlack = captured.filter(p => p.color === "w");

  let message = "Game in Progress";

  if (status === "checkmate") {
    message = `${position.turn === "w" ? "Black" : "White"} Wins - Checkmate`;
  } else if (status === "stalemate") {
    message = "Draw - Stalemate";
  } else if (timeout) {
    message = `${whiteTime === 0 ? "Black" : "White"} Wins - Time Out`;
  } else if (status === "check") {
    message = "Check!";
  }

  return (
    <div className="app">
      <h1>Chess Game</h1>

      <div className="game-container">
        <div className="board-section">

          <div className={`player ${position.turn === "b" ? "active" : ""}`}>
            <h3>Black Player</h3>
            <span>{formatTime(blackTime)}</span>
          </div>

          <div className="board">
            {position.board.map((piece, index) => {
              const row = Math.floor(index / 8);
              const col = index % 8;
              const dark = (row + col) % 2 === 1;

              return (
                <div
                  key={index}
                  className={`square ${dark ? "dark" : "light"}
                    ${selected === index ? "selected" : ""}
                    ${position.lastMove &&
                    (position.lastMove.from === index ||
                    position.lastMove.to === index) ? "last-move" : ""}`}
                  onClick={() => handleSquare(index)}
                >
                  {piece && (
                    <span className={`piece ${piece.color}`}>
                      {symbols[piece.color][piece.type]}
                    </span>
                  )}

                  {possible.includes(index) && (
                    <span className={piece ? "capture-dot" : "move-dot"} />
                  )}

                  {col === 0 && <small className="rank">{8 - row}</small>}
                  {row === 7 && <small className="file">{"abcdefgh"[col]}</small>}
                </div>
              );
            })}
          </div>

          <div className={`player ${position.turn === "w" ? "active" : ""}`}>
            <h3>White Player</h3>
            <span>{formatTime(whiteTime)}</span>
          </div>

          <div className="buttons">
            <button onClick={undoMove} disabled={!history.length}>Undo</button>
            <button onClick={() => setRunning(!running)} disabled={gameOver}>
              {running ? "Pause" : "Resume"}
            </button>
            <button onClick={restartGame}>Restart</button>
          </div>
        </div>

        <div className="side-panel">
          <h2>Game Status</h2>
          <p>Turn: {position.turn === "w" ? "White" : "Black"}</p>
          <h3>{message}</h3>

          <h2>Move History</h2>
          <div className="move-list">
            {moves.map((move, index) => (
              <div className="move-row" key={index}>
                {move.color === "w" ? (
                  <>
                    <span>{Math.floor(index / 2) + 1}.</span>
                    <span>{move.san}</span>
                  </>
                ) : (
                  <>
                    <span></span>
                    <span>{move.san}</span>
                  </>
                )}
              </div>
            ))}
          </div>

          <h2>Captured Pieces</h2>
          <p>White: {capturedByWhite.map(p => symbols.b[p.type]).join(" ") || "None"}</p>
          <p>Black: {capturedByBlack.map(p => symbols.w[p.type]).join(" ") || "None"}</p>
        </div>
      </div>

      {promotion && (
        <div className="promotion">
          <h3>Select Promotion Piece</h3>
          {["Q", "R", "B", "N"].map(type => (
            <button
              key={type}
              onClick={() => makeMove(promotion.from, promotion.to, type)}
            >
              {symbols[position.turn][type]}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;
