Chess Game Using React.js

About

This is a React application for an offline two-player chess game. It allows two players to play chess on the same device by taking alternate turns. It implements chess rules, legal move validation, check and checkmate detection without using any external chess library.

Technologies Used

React.js
JavaScript
JSX
CSS
React Hooks
HTML

Features

Displays an interactive 8x8 chess board
Shows all chess pieces in their initial positions
Validates legal moves for all chess pieces
Prevents illegal moves
Supports turn-based gameplay for two players
Detects check and checkmate conditions
Provides countdown timers for both players
Pauses the inactive player's timer
Displays moves in standard chess notation
Tracks move history
Allows users to undo the last move
Highlights legal moves for selected pieces
Displays captured pieces
Supports pawn promotion
Provides Pause and Resume functionality
Allows users to restart the game
Provides a responsive user interface

How to Run

Create a React project using Vite
Run npm install
Create App.jsx inside the src folder
Create chess.js inside the src folder
Add styling in App.css
Add the React rendering code in main.jsx
Open the terminal in the project folder
Run npm run dev
Open the local URL in your browser

Author

Yash